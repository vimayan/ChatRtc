import { createContext } from "react";

const ChatContext = createContext();

export default ChatContext;
